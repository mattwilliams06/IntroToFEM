function C=CompM(K, M, dampK, dampM)

  C = dampM*M + dampK*K;
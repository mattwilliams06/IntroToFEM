function current=GetPrev(s, e, current)
current=current-1;
if current<s; current=e; end;
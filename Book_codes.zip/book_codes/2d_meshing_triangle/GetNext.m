function current=GetNext(s, e, current)
current=current+1;
if current>e; current=s; end;